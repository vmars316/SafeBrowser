Welcome to SafeBrowser .
   SafeBrowser is a Free Internet Browser , based on MS Edge (Chromium) Browser . It is written in the PureBasic Language .
   'Safe' , because users can only visit sites that are Pre-Approved and stored in an Approved-Links-File .
   SafeBrowser comes with a SafeBrowser Editor to maintain the Approved-Links-Files .

   At StartUp , SafeBrowser (SB) opens with it's homepage : http://safebrowser.us/SafeBrowserHome.html as shown above .

  The 1st line of the TAB contains 'Navigation Buttons , an Input field' followed by a Drop-Down-Menu .
   [ < Go Back ]    [ Go Forward > ]    [ Refresh Page ]     [ Go Home ]     [http://safebrowser.us/SafeBrowserHome.html ]       Drop-Down-Menu    
   The name of the Button indicates what it does , all except for the Input-Box .

   The [ Input-Box ] has a dual purpose .
     1) It shows the address of the page being display .
     2) It can serve as a Search argument for the 'DuckDuckGo.com' Search-Engine .
       If you blank out the Input-Box , and enter something else , say , "Sweden" , and then press the 'Enter-Key' ,
       then the 'DuckDuckGo Search-Engine' will open , showing info about 'Sweden' .
      
   When you are ready to 'Quit' SB , either CLick on the 'X' Button in the top right of the Browser window ,
   OR CLick on the Drop-Down Menu , then Click on 'Quit' .